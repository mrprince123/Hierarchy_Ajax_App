@include('Layout.header')


@yield('components')


{{-- @include('Layout.footer') --}}
